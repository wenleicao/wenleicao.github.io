  declare @Resellergroup varchar(20)
  select @Resellergroup ='group2'
  if object_id ('tempdb..#tmpSpecificReseller') is not null drop table #tmpSpecificReseller
  --copy table shell to temp table
  select * into #tmpSpecificReseller from  [AdventureWorksDW2012].[dbo].[FactResellerSales] 
  where 1=2 
  --use insert table from.... instead
  if @Resellergroup = 'All' 
  begin 
  insert into #tmpSpecificReseller select * from  [AdventureWorksDW2012].[dbo].[FactResellerSales]
  end 
  if @Resellergroup = 'group1'
  begin
  insert into #tmpSpecificReseller select * from  [AdventureWorksDW2012].[dbo].[FactResellerSales]
  where ResellerKey in (679, 203)
  end 
   if @Resellergroup = 'group2'
  begin
  insert into #tmpSpecificReseller select * from  [AdventureWorksDW2012].[dbo].[FactResellerSales]
  where ResellerKey in (480, 491)
  end 
