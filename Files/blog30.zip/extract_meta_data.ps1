﻿$path = "C:\Users\wcao2\Documents\blog\"
$files = Get-ChildItem $path -Filter *.csv
$outarray = @()
#$files
foreach ($file in $files) {
$newPath = join-path $path $file.Name
$file1=Get-Content -path $newPath 
$header = $file1 | select -First 1
#$header
$myobj = "" | select "folder", "tablename", "columnstring"
$myobj.folder = $path
$myobj.tablename = $file.Name
$myobj.columnstring = $header
$outarray += $myobj
$myobj = $null
}
$outarray | Export-Csv c:\temp\powershell\blog_source_flat_file_header.csv -NoTypeInformation