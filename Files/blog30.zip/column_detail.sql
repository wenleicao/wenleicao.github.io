USE [yourdatabasename]
GO

/****** Object:  View [dbo].[vwBiml_sameple_column_detail]    Script Date: 11/10/2019 3:16:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[vwBiml_sameple_column_detail] as
with metadata as (
select 
folder, 
tablename,
--columnstring,
reverse (left(reverse (columnstring), charindex (',', reverse (columnstring), 1)-1)) as lastcolumn,
cs.value as [column]
from [biml].[source_flat_file_header]
cross apply string_split (columnstring, ',') cs )
select
tablename=left(tablename, charindex('.', tablename, 1)-1) ,
[column] as column_name, 
'varchar' as data_type,
case when [column] like '%desc%' then 4000 
     else 50 end as column_length, 
case when lastcolumn = [column] then ' ' else ',' end as delimiter, 
case when lastcolumn = [column] then 'CRLF ' else ',' end as delimiter_flatfile 
from metadata
GO


