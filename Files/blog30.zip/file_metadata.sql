USE [yourdatabasename]
GO

/****** Object:  View [dbo].[vwbiml_sample_file]    Script Date: 11/10/2019 3:17:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vwbiml_sample_file] as
select 
folder, 
flat_file_name = left(tablename, charindex('.', tablename, 1)-1), 
flat_file_type = right (tablename, len(tablename)-charindex('.', tablename, 1))
from [biml].[source_flat_file_header]
GO

select * from [biml].[source_flat_file_header]


