create table yourdb.samplewithblank as (
select '   donald ' as "name", '       investment'  as course  from (select 1 as "dummy") as "dual"
union
select ' wenlei ' as "name", 'data science   '  as course  from (select 1 as "dummy") as "dual"


)
with data 
no primary index;

select * from yourdb.samplewithblank;

--testing
call yourdb.sp_remove_blank ('yourdb', 'samplewithblank');
select * from yourdb.samplewithblank;
--drop table yourdb.samplewithblank;


