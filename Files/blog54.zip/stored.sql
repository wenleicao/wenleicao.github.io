REPLACE PROCEDURE yourdb.sp_remove_blank( in dbname varchar(50), in tablename varchar(100) )
SQL SECURITY INVOKER
BEGIN
    DECLARE lv_update_txt      VARCHAR(20000);
    declare columnname varchar(50);
    declare proc_msg varchar(200);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN          
       SET proc_msg = 'Procedure Failed with'||SQLCODE;
    /* Any Error handling code if required */
    END;

    L0: 
    FOR update_cursor AS update_list
    /* Getting the list of rows from other table */
    CURSOR FOR    
        
	 SELECT columnname
       FROM DBC.ColumnsV WHERE DatabaseName = :dbname
       AND TableName = :tablename
       and columntype in ('CV', 'CF', 'CO')  --string column

    DO  
    
    
    set columnname = update_cursor.columnname ;  
    SET lv_update_txt ='update '||dbname||'.'||tablename||' set '||columnname||' = trim(both from '||columnname||')';
	--print(lv_update_txt);   
       
    /* Executing update statement from variable */
       EXECUTE IMMEDIATE lv_update_txt;
    END FOR L0;
    
    

    SET proc_msg = 'Procedure completed successfully';
END;