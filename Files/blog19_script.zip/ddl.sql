create table dbo.dashboard_subscription ( 
ParamID int identity primary key,
UserEmail varchar(100),
DashboardName varchar(200),
DashboardURL  varchar(max),
TableName  varchar(200),
ColumnName varchar(100),
ColumnValue varchar(200)
)

--developer need to maintain this script to keep the table up to date
insert into AdventureWorksDW2012.dbo.dashboard_subscription 
(
UserEmail ,
DashboardName,
DashboardURL,
TableName ,
ColumnName,
ColumnValue 
)
select 'wenlei.Cao@example.com', 'Dashboard_test', 'https://app.powerbi.com/groups/me/reports/c4c5004b-31d0-4330-8cad-de0fb8f71563/ReportSection', 'student', 'StudentName', 'Mary'
union all
select 'John.Doe@example.com', 'Dashboard_test', 'https://app.powerbi.com/groups/me/reports/c4c5004b-31d0-4330-8cad-de0fb8f71563/ReportSection', 'student', 'StudentName', 'Mary'
union all
select 'John.Doe@example.com', 'Dashboard_test', 'https://app.powerbi.com/groups/me/reports/c4c5004b-31d0-4330-8cad-de0fb8f71563/ReportSection', 'class', 'ClassName', 'Math'
