use msdb
go

--prepare for pivot filter
if object_id ('tempdb..#tmp_test1') is not null drop table #tmp_test1
select 
*,
TableName + '/' + ColumnName + ' eq ''''' + ColumnValue as dashboardfilter,
'param' + cast( row_number() over (partition by useremail, dashboardname order by useremail, dashboardname, paramid) as varchar(3)) as paramnumber
into #tmp_test1
from AdventureWorksDW2012.dbo.dashboard_subscription 
order by paramid

--select * from   #tmp_test1


--complete pivot filter
if object_id ('tempdb..#tmp_test2') is not null drop table #tmp_test2
select
useremail, dashboardname, DashboardURL,
param1 + case when param2 is null then '' else    ''''' and ' + param2 end as dashboardfilter 
into  #tmp_test2                
from  (select useremail, dashboardname, paramnumber, dashboardfilter, DashboardURL from #tmp_test1 ) a    --only include group column
pivot (
max(dashboardfilter)
for paramnumber in ([param1], [param2])
) p 

--select * from   #tmp_test2    


--use cursor and dynamic sql to send email one record at a time



declare 
@sqltext varchar(max),
@UserEmail varchar(100),
@DashboardName varchar(200),
@DashboardURL  varchar(max),
@Dashboardfilter varchar(max)

DECLARE createEmail CURSOR for 
		select useremail, dashboardname,DashboardURL,  dashboardfilter  from #tmp_test2
 
	OPEN createEmail
	FETCH NEXT FROM createEmail
	INTO @useremail, @dashboardname,@DashboardURL,  @dashboardfilter

	WHILE @@FETCH_STATUS=0
	  BEGIN 
		SET @sqltext = 'EXEC sp_send_dbmail @profile_name=''BeaconETL'',
						@recipients=''' + @UserEmail +''',
						@subject=''' + @DashboardName +' is ready'',
						@body=''please click the following link
						<' +@DashboardURL +'?filter=' + @Dashboardfilter + '''''>'''
					
		
		PRINT @sqltext
		
			EXEC(@sqltext);

		FETCH NEXT FROM createEmail
			INTO @useremail, @dashboardname,@DashboardURL,  @dashboardfilter
	  END
  
  
	CLOSE createEmail
	DEALLOCATE createEmail
