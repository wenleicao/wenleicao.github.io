--create a view as sample data in your db
alter view dbo.vwdds_test
as
select 
'Prof. alpha' as teacher, 'Prof.alpha@SomeUniv.edu' as teacheremail, 'John Doe' as StudentName, 'Course1' as Course, 'A' as Score, 'john.doe@SomeUniv.edu' as email
union 
select 
'Prof. alpha', 'Prof.alpha@SomeUniv.edu','John Doe', 'Course2', 'B',  'john.doe@SomeUiv.edu'
union 
select 
'Prof. alpha', 'Prof.alpha@SomeUniv.edu', 'Don Trump', 'Course2', 'B', 'Don.Trump@SomeUniv.edu'  
union
select 
'Prof. beta', 'Prof.beta@SomeUniv.edu', 'Don Trump', 'Course3', 'F', 'Don.Trump@SomeUniv.edu'
union
select
'Prof. gamma', 'Prof.gamma@SomeUniv.edu', 'Don Trump', 'Course4', 'C', 'Don.Trump@SomeUniv.edu'
go

select * from dbo.vwdds_test

select 
distinct 
course
from dbo.vwdds_test
where teacher = iif(@TeacherSwitch = 'All', teacher, @TeacherSwitch)


--first non working dds
select distinct 
teacher, 
teacheremail,
case teacher when 'Prof. alpha' then 'Course1,Course2'
             when 'Prof. beta' then 'Course3'
			 when 'Prof. gamma' then 'Course4' end as course,
'wcao2@someuniv.edu' as testemail
from dbo.vwdds_test


--working dds
select distinct 
teacher, 
teacheremail,
'wcao2@someuniv.edu' as testemail
from dbo.vwdds_test