from sklearn.ensemble import RandomForestClassifier
from joblib import load
import pandas as pd
import pickle

#odel = load(r"C:\Users\Wenlei\Documents\Python Scripts\test\flask\iris_rf_model.pkl")
with open('iris_rf_model2.pkl', 'rb') as f:
    # Load the data from the file
    model2 = pickle.load(f)
#model = load(r'iris_rf_model.pkl')
X = pd.Series([4.4, 3, 1.3, 0.2], index=['sepal length (cm)',	'sepal width (cm)',	'petal length (cm)', 'petal width (cm)']).to_frame().T
prediction  =  model2.predict(X)[0]
print(prediction)