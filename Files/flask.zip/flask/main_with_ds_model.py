from flask import Flask, request, jsonify
#from sklearn.ensemble import RandomForestClassifier
import pickle
import  pandas as pd

app = Flask(__name__)

with open('iris_rf_model2.pkl', 'rb') as f:
    # Load the data from the file
    model = pickle.load(f)

@app.route('/api/iris', methods=['GET'])
def get_items():
    # Access query parameters
    sepal_length = request.args.get('sepal_length')
    sepal_width = request.args.get('sepal_width')
    petal_length = request.args.get('petal_length')
    petal_width = request.args.get('petal_width')  

    params = {
        "sepal_length" : sepal_length,
        "sepal_width":sepal_width,
        "petal_length": petal_length,
        "petal_width":petal_width
    } 

      
    #prepare data, since model fit with dataframe, need to format like a dataframe
    X = pd.Series([sepal_length, sepal_width, petal_length, petal_width], index=['sepal length (cm)',	'sepal width (cm)',	'petal length (cm)', 'petal width (cm)']).to_frame().T
    prediction  =  model.predict(X)[0]  #predict one at a time  


    return  jsonify({
        'params': params,         
        'prediction': prediction 
    })

if __name__ == '__main__':
    app.run(debug=True)


#when user need to pass argument to model, such as a conversation, use parser, or other tool like mashmallow
#https://30dayscoding.com/blog/flask-get-request-parameters
#https://www.google.com/search?q=flask+rest+api+get+with+argument&oq=flask+rest+api++get+with+argument&gs_lcrp=EgRlZGdlKgYIABBFGDkyBggAEEUYOTIICAEQABgWGB4yCggCEAAYgAQYogQyCggDEAAYogQYiQUyCggEEAAYogQYiQXSAQkxODU1MWowajSoAgCwAgE&sourceid=chrome&ie=UTF-8