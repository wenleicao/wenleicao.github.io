USE [BI_Dev]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_getUnderlyingTable]    Script Date: 1/1/2020 10:37:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--Wenlei
--get a list objects which another object used
--select * from udf_getUnderlyingTableWithLevel ('dbo.usp_readmisson_40')

alter function [dbo].[udf_getUnderlyingTable] 
(@objectfullname varchar(100)) 
returns table 
as
return 
SELECT DISTINCT 
      [object_name] = SCHEMA_NAME(o.[schema_id]) + '.' + o.name
    , o.type_desc
FROM sys.dm_sql_referenced_entities (@objectfullname, 'OBJECT') d
JOIN sys.objects o ON d.referenced_id = o.[object_id]
WHERE o.[type] IN ('U', 'V', 'FN', 'IF', 'TF', 'P')
GO


