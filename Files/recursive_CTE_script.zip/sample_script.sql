--create table
create table tmp.Student (
StudentID int,
StudentName varchar(50),
DOB datetime 
)

create table tmp.Course (
CourseID int,
CourseName varchar(50)
)

create table tmp.StudentCourseBridge (
StudentID int,
CourseID int
)

--populate table
insert into tmp.Student
values (1, 'Mike', '1997-07-01'), (2, 'Susan', '1996-12-25'), (3, 'Tom', '1998-01-05'), (4, 'Lisa', '1996-03-21')

insert into tmp.Course
values (1, 'Data Science 101'), (2, 'Business Intillignece'), (3, 'Machine Learning'), (4, 'Algorithm')

insert into tmp.StudentCourseBridge
values (1, 1), (1, 3), (2,4), (2, 2), (3, 1), (3, 4), (4, 3), (4, 2), (4, 1)
go
--create a view
create view tmp.vwStudentCourse
as 
select a.StudentID, a.StudentName, a.DOB, c.CourseID, c.CourseName
from tmp.Student a 
join tmp.StudentCourseBridge b  on a.StudentID = b.StudentID
join tmp.Course c on b.CourseID =c.CourseID
go
--create a function calculate age 
CREATE FUNCTION tmp.udf_getAge 
(@DiffFrom DATE, @DiffTo DATE)
RETURNS INT
AS
BEGIN
    DECLARE @NumOfYears INT
    SET @NumOfYears = (SELECT 
                         DATEDIFF(YEAR, @DiffFrom, @DiffTo) + 
                         CASE 
                           WHEN MONTH(@DiffTo) < MONTH(@DiffFrom) THEN -1 
                           WHEN MONTH(@DiffTo) > MONTH(@DiffFrom) THEN 0 
                           ELSE 
                             CASE WHEN DAY(@DiffTo) < DAY(@DiffFrom) THEN -1 ELSE 0 END 
                         END)
    IF @NumOfYears < 0
    BEGIN
        SET @NumOfYears = 0;
    END

    RETURN @NumOfYears;
END
go
--create stored procedure to see who attend a give class
create proc tmp.usp_getCourseStudentlist (@coursename varchar(50))
as
select 
CourseID,
CourseName,
StudentID,
StudentName,
tmp.udf_getAge (DOB, getdate()) as Age
from tmp.vwStudentCourse
where CourseName = @coursename

exec tmp.usp_getCourseStudentlist 'Data Science 101'

--check our Recursive CTE function
select * from [dbo].[udf_getUnderlyingTableWithLevel] ('tmp.usp_getCourseStudentlist')
