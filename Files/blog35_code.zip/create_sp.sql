create proc dbo.usp_get_table_html @course varchar(50) , @emailbody nvarchar(max) output
as
--declare 
--@course varchar(50),
--@emailbody  nvarchar(max)
--set @course = 'Data Science Intro'

drop table if exists #tmp_result
select 
*
into #tmp_result
from tmp.student 
where Course = @course

--select * from #tmp_result

	DECLARE @xml NVARCHAR(MAX)
	DECLARE @body NVARCHAR(MAX)

	SET @xml = CAST(( SELECT [StudentID] AS 'td','',
	[StudentName] AS 'td','',
	[Course] AS 'td','',
	case score when 'F' then 'background-color:red'
	           when 'C' then 'background-color:yellow' end AS 'td/@style',
	[Score] AS 'td'
	FROM #tmp_result
	ORDER BY StudentID
	FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))
	
	SET @body ='<html><body><H3>Student Score Report for ' +  @course + '</H3>
	<table border = 1> 
	<tr  style="background-color:silver">
	 <th> StudentID </th> <th> StudentName </th> <th> Course </th><th> Score </th></tr>'    

	SET @emailbody = @body + @xml +'</table></body></html>'

--select @emailbody



exec 
