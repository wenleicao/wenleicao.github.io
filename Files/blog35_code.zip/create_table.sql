create  table tmp.student 
(
StudentID int identity primary key, 
StudentName  varchar(50),
Course varchar(50),
Score char(1)
)

--insert sample data
insert into tmp.student 
values 
('Lisa', 'Data Science Intro', 'A'), 
('Tom', 'Data Science Intro', 'B'), 
('Lisa', 'Algorithm', 'B'), 
('Michael', 'Data Science intro','A'),
('Jack', 'Data Science Intro', 'F'), 
('Kathleen', 'Algorithm', 'C'),
('Jennifer', 'Data Science Intro', 'C')

select * from tmp.student 