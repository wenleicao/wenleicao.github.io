--get version to be used
"select version from tmp.change_tracking_version where tablename ='tmp.sales_raw'"

--in tjavarow
context.version1 = row2.version;
System.out.println("Processing file: "+(new Long(context.version1).toString()));

--record current version
"--insert new version number to version table
update tmp.change_tracking_version
set Updatedate = getdate(), version = CHANGE_TRACKING_CURRENT_VERSION()
where tablename ='tmp.sales_raw'
 "


--table prep  delete   deleted and updated
"delete a
from 
[tmp].[sales_raw_copy] a 
join CHANGETABLE(CHANGES tmp.sales_raw, " + context.version1 + ") b on a.saleid = b.saleid 
where b.sys_change_operation in ( 'D', 'U')
"

--load updated and insert
"
select 
a.Saleid,
a.Customer,
a.SaleAmount,
a.SaleDate
from 
[tmp].[sales_raw] a
join CHANGETABLE(CHANGES tmp.sales_raw, " + context.version1+ ") b on a.saleid = b.saleid
where b.sys_change_operation in ( 'I', 'U')
"
