--get a tracking table  only need to run once
drop table if exists tmp.change_tracking_version
create table tmp.change_tracking_version
(tablename varchar(100), version bigint, UpdateDate smalldatetime )

--insert the most update version number, only need to run once
truncate table tmp.change_tracking_version   
insert tmp.change_tracking_version
select 'tmp.sales_raw',  CHANGE_TRACKING_CURRENT_VERSION(), getdate()

--select max(version) from tmp.change_tracking_version where tablename ='tmp.sales_raw'

--test for insertion, update and delete, copy the sales table
truncate table  tmp.sales_raw_copy
SET IDENTITY_INSERT tmp.sales_raw_copy ON
insert tmp.sales_raw_copy (saleid, customer, SaleAmount, SaleDate)
select saleid, customer, SaleAmount, SaleDate from tmp.sales_raw
SET IDENTITY_INSERT tmp.sales_raw_copy off

--show sales_raw_copy and compare with sales_raw
--select * from tmp.sales_raw
select * from tmp.sales_raw_copy
select * from tmp.sales_raw 
except
select * from tmp.sales_raw_copy
select * from tmp.sales_raw_copy 
except
select * from tmp.sales_raw

--select * from tmp.sales_raw
SET IDENTITY_INSERT tmp.sales_raw ON
insert into tmp.sales_raw (saleid, customer, SaleAmount, SaleDate)  --insert
values  (14, 'michael', 5, '2020-05-08')
update tmp.sales_raw set customer = 'wenlei' where saleid =8  --update
delete tmp.sales_raw where saleid =5        --delete
SET IDENTITY_INSERT tmp.sales_raw off

--check difference
select * from tmp.sales_raw
except
select * from tmp.sales_raw_copy

select * from tmp.sales_raw_copy
except
select * from tmp.sales_raw


--run script at the talend
--script in another file

--check again
select * from tmp.sales_raw_copy
select * from tmp.sales_raw 
except
select * from tmp.sales_raw_copy
select * from tmp.sales_raw_copy 
except
select * from tmp.sales_raw